#pragma once
#include <vector>
#include "json.h"

uintptr_t gameAsm;
std::vector<OffsetRequest> functionOffsets;
