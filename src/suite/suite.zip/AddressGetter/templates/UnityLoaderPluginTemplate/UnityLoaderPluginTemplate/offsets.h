#pragma once

uintptr_t gameAsm;
